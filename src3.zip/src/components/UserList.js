import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function UserList({ users, setUsers }) {
  const navigate = useNavigate();
  const [deletingId, setDeletingId] = useState(null);

  // Refresh modal
  const [showRefreshModal, setShowRefreshModal] = useState(false);

  // Info modal
  const [selectedUser, setSelectedUser] = useState(null);

  // ----- INFO -----
  const handleInfo = (user) => setSelectedUser(user);
  const closeInfo = () => setSelectedUser(null);

  // ----- REFRESH -----
  const handleRefreshClick = () => setShowRefreshModal(true);
  const cancelRefresh = () => setShowRefreshModal(false);

  const confirmRefresh = async () => {
    setShowRefreshModal(false);
    try {
      const res = await fetch("https://jsonplaceholder.typicode.com/users");
      const data = await res.json();
      const normalized = data.map((u, i) => ({ ...u, id: i + 1 }));
      setUsers(normalized);
      toast.success("Data refreshed");
    } catch {
      toast.error("Refresh failed");
    }
  };

  // ----- EDIT -----
  const handleEdit = (id) => {
    navigate(`/edit/${id}`);
  };

  // ----- DELETE -----
  const handleDelete = async (id) => {
    if (!window.confirm("Delete this user?")) return;

    setDeletingId(id);
    try {
      await fetch(`https://jsonplaceholder.typicode.com/users/${id}`, { method: "DELETE" });

      const filtered = users.filter((u) => u.id !== id);
      const reIndexed = filtered.map((u, i) => ({ ...u, id: i + 1 }));
      setUsers(reIndexed);

      toast.success("User deleted");
    } catch {
      toast.error("Delete failed");
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="panel">
      <div className="panel-header">
        <h2>Visitor bookings</h2>

        <div className="panel-actions">
          <button className="btn small" onClick={handleRefreshClick}>Refresh</button>
          <button className="btn outline small" onClick={() => navigate("/add")}>+ Add</button>
        </div>
      </div>

      {/* TABLE VIEW */}
      <div className="table-responsive">
        <table className="dark-table">
          <thead>
            <tr>
              <th className="id-col">ID</th>
              <th>Name</th>
              <th>Email</th>
              <th className="phone-col">Phone</th>
              <th className="actions-col">Actions</th>
            </tr>
          </thead>

          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.id}</td>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>{u.phone}</td>

                <td className="actions-col">
                  <button className="btn tiny" onClick={() => handleEdit(u.id)}>Edit</button>

                  <button className="btn tiny danger"
                    onClick={() => handleDelete(u.id)}>
                    {deletingId === u.id ? "Deleting..." : "Delete"}
                  </button>

                  <button className="btn tiny outline" onClick={() => handleInfo(u)}>i</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* CARD VIEW (MOBILE) */}
      <div className="card-grid">
        {users.map((u) => (
          <div className="user-card" key={`card_${u.id}`}>
            <div className="card-top">
              <div className="card-id">#{u.id}</div>
              <div className="card-name">{u.name}</div>
            </div>

            <div className="card-body">
              Email: {u.email} <br />
              Phone: {u.phone}
            </div>

            <div className="card-footer">
              <button className="btn tiny" onClick={() => handleEdit(u.id)}>Edit</button>
              <button className="btn tiny danger" onClick={() => handleDelete(u.id)}>
                {deletingId === u.id ? "Deleting..." : "Delete"}
              </button>
              <button className="btn tiny outline" onClick={() => handleInfo(u)}>i</button>
            </div>
          </div>
        ))}
      </div>

      {/* INFO MODAL */}
      {selectedUser && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h3>User Details</h3>

            <p><strong>ID:</strong> {selectedUser.id}</p>
            <p><strong>Name:</strong> {selectedUser.name}</p>
            <p><strong>Email:</strong> {selectedUser.email}</p>
            <p><strong>Phone:</strong> {selectedUser.phone}</p>
            <p><strong>City:</strong> {selectedUser.address?.city ?? "Not available"}</p>
            <p><strong>Website:</strong> {selectedUser.website ?? "Not available"}</p>
            <p><strong>Company:</strong> {selectedUser.company?.name ?? "Not available"}</p>

            <div className="modal-buttons">
              <button className="confirm" onClick={closeInfo}>Close</button>
            </div>
          </div>
        </div>
      )}

      {/* REFRESH MODAL */}
      {showRefreshModal && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h3>Refresh User Data?</h3>
            <p>This will reload all user data and remove temporary changes.</p>

            <div className="modal-buttons">
              <button className="confirm" onClick={confirmRefresh}>Refresh</button>
              <button className="cancel" onClick={cancelRefresh}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default UserList;
