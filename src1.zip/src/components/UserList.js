import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function UserList({ users, setUsers, loading }) {
  const navigate = useNavigate();
  const [deletingId, setDeletingId] = useState(null);

  // Go to Edit Page
  const handleEdit = (id) => {
    navigate(`/edit/${id}`);
  };

  // Delete User (with error handling + reindex)
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;

    setDeletingId(id);

    try {
      const res = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) throw new Error("Delete failed");

      const filtered = users.filter((u) => u.id !== id);
      const reIndexed = filtered.map((u, idx) => ({ ...u, id: idx + 1 }));

      setUsers(reIndexed);
      toast.success("User deleted");
    } catch (err) {
      toast.error("Failed to delete user. Try again.");
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="userlist-wrap">
      <h2 className="section-title">Users</h2>

      {loading ? (
        <p className="info">Loading users...</p>
      ) : users.length === 0 ? (
        <p className="info">No users found.</p>
      ) : (
        <>
          {/* Desktop/table view */}
          <div className="table-responsive">
            <table className="user-table">
              <thead>
                <tr>
                  <th className="col-id">ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th className="col-phone">Phone</th>
                  <th className="col-actions">Actions</th>
                </tr>
              </thead>

              <tbody>
                {users.map((user) => (
                  <tr key={user.id}>
                    <td className="col-id">{user.id}</td>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td className="col-phone">{user.phone}</td>
                    <td className="col-actions">
                      <button className="btn" onClick={() => handleEdit(user.id)}>
                        Edit
                      </button>

                      <button
                        className="btn btn-danger"
                        onClick={() => handleDelete(user.id)}
                        disabled={deletingId === user.id}
                      >
                        {deletingId === user.id ? "Deleting..." : "Delete"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Card view (mobile) */}
          <div className="card-grid">
            {users.map((user) => (
              <div className="user-card" key={`card-${user.id}`}>
                <div className="card-row">
                  <strong>ID:</strong> {user.id}
                </div>
                <div className="card-row">
                  <strong>Name:</strong> {user.name}
                </div>
                <div className="card-row">
                  <strong>Email:</strong> {user.email}
                </div>
                <div className="card-row">
                  <strong>Phone:</strong> {user.phone}
                </div>

                <div className="card-actions">
                  <button className="btn" onClick={() => handleEdit(user.id)}>
                    Edit
                  </button>

                  <button
                    className="btn btn-danger"
                    onClick={() => handleDelete(user.id)}
                    disabled={deletingId === user.id}
                  >
                    {deletingId === user.id ? "Deleting..." : "Delete"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default UserList;
