import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import UserList from "./components/UserList";
import CreateUser from "./pages/CreateUser";
import EditUser from "./pages/EditUser";

import "./App.css";

function App() {
  const [users, setUsers] = useState([]);

  // Warn user when reloading tab
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      e.preventDefault();
      e.returnValue = "All data will be lost if you reload this page!";
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, []);

  // Fetch Users Initially
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((res) => res.json())
      .then((data) => setUsers(data))
      .catch(() => toast.error("❌ Failed to fetch users"));
  }, []);

  return (
    <Router>
      <div style={{ padding: "20px" }}>
        {/* Toast System */}
        <ToastContainer position="top-right" />

        {/* NAVBAR */}
        <nav style={{ marginBottom: "20px" }}>
          <Link to="/" style={{ marginRight: "15px" }}>
            Home
          </Link>
          <Link to="/add">Add User</Link>
        </nav>

        {/* ROUTES */}
        <Routes>
          <Route path="/" element={<UserList users={users} setUsers={setUsers} />} />
          <Route path="/add" element={<CreateUser users={users} setUsers={setUsers} />} />
          <Route path="/edit/:id" element={<EditUser users={users} setUsers={setUsers} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
