import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function CreateUser({ users, setUsers }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic validation
    if (!name.trim() || !email.trim() || !phone.trim()) {
      toast.error("Please fill all fields");
      return;
    }

    const newUser = {
      id: users.length + 1,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
    };

    setSubmitting(true);

    try {
      const res = await fetch("https://jsonplaceholder.typicode.com/users", {
        method: "POST",
        body: JSON.stringify(newUser),
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
        },
      });

      if (!res.ok) throw new Error("Create failed");

      // locally add (temporary)
      setUsers([...users, newUser]);
      toast.success("User added");

      // clear
      setName("");
      setEmail("");
      setPhone("");

      // go to home
      navigate("/");
    } catch (err) {
      toast.error("Failed to create user. Try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="form-wrap">
      <h2 className="section-title">Add New User</h2>

      <form className="form" onSubmit={handleSubmit}>
        <label className="label">
          Name
          <input
            className="input"
            type="text"
            placeholder="Enter name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </label>

        <label className="label">
          Email
          <input
            className="input"
            type="email"
            placeholder="Enter email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>

        <label className="label">
          Phone
          <input
            className="input"
            type="text"
            placeholder="Enter phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
          />
        </label>

        <div style={{ marginTop: 12 }}>
          <button className="btn" type="submit" disabled={submitting}>
            {submitting ? "Adding..." : "Add User"}
          </button>
        </div>
      </form>
    </div>
  );
}

export default CreateUser;
