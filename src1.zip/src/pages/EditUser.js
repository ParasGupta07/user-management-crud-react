import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";

function EditUser({ users, setUsers }) {
  const { id } = useParams();
  const navigate = useNavigate();

  const numericId = parseInt(id, 10);
  const userToEdit = users.find((u) => u.id === numericId);

  const [name, setName] = useState(userToEdit?.name || "");
  const [email, setEmail] = useState(userToEdit?.email || "");
  const [phone, setPhone] = useState(userToEdit?.phone || "");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (userToEdit) {
      setName(userToEdit.name);
      setEmail(userToEdit.email);
      setPhone(userToEdit.phone);
    }
  }, [userToEdit]);

  if (!userToEdit) {
    return <div className="info">User not found</div>;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!name.trim() || !email.trim() || !phone.trim()) {
      toast.error("Please fill all fields");
      return;
    }

    const updated = {
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
    };

    setSubmitting(true);

    try {
      const res = await fetch(`https://jsonplaceholder.typicode.com/users/${numericId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });

      if (!res.ok) throw new Error("Update failed");

      const updatedList = users.map((u) =>
        u.id === numericId ? { ...u, ...updated } : u
      );

      setUsers(updatedList);
      toast.success("User updated");
      navigate("/");
    } catch (err) {
      toast.error("Failed to update user");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="form-wrap">
      <h2 className="section-title">Edit User</h2>

      <form className="form" onSubmit={handleSubmit}>
        <label className="label">
          Name
          <input
            className="input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </label>

        <label className="label">
          Email
          <input
            className="input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            required
          />
        </label>

        <label className="label">
          Phone
          <input
            className="input"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
          />
        </label>

        <div style={{ marginTop: 12 }}>
          <button className="btn" type="submit" disabled={submitting}>
            {submitting ? "Updating..." : "Update User"}
          </button>
        </div>
      </form>
    </div>
  );
}

export default EditUser;
