import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function UserList({ users, setUsers, loading }) {
  const navigate = useNavigate();
  const [deletingId, setDeletingId] = useState(null);

  const handleEdit = (id) => {
    navigate(`/edit/${id}`);
  };

  const handleDelete = async (id) => {
    // keep existing confirm behavior
    if (!window.confirm("Are you sure you want to delete this user?")) return;

    setDeletingId(id);
    try {
      const res = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) throw new Error("Delete failed");

      const filtered = users.filter((u) => u.id !== id);
      const reIndexed = filtered.map((u, idx) => ({ ...u, id: idx + 1 }));
      setUsers(reIndexed);

      toast.success("User deleted");
    } catch (err) {
      toast.error("Failed to delete user. Try again.");
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="panel">
      <div className="panel-header">
        <h2>Visitor bookings</h2>
        <div className="panel-actions">
          <button className="btn small" onClick={() => toast.info("Refresh data not supported")}>
            Refresh
          </button>
          <button className="btn outline small" onClick={() => navigate("/add")}>
            + Add
          </button>
        </div>
      </div>

      {loading ? (
        <div className="loader">Loading users…</div>
      ) : users.length === 0 ? (
        <p className="muted">No users found.</p>
      ) : (
        <>
          <div className="table-responsive">
            <table className="dark-table">
              <thead>
                <tr>
                  <th className="id-col">ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th className="phone-col">Phone</th>
                  <th className="actions-col">Actions</th>
                </tr>
              </thead>

              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td className="id-col">{u.id}</td>
                    <td className="name-col">{u.name}</td>
                    <td className="email-col">{u.email}</td>
                    <td className="phone-col">{u.phone}</td>
                    <td className="actions-col">
                      <button className="btn tiny" onClick={() => handleEdit(u.id)}>Edit</button>
                      <button
                        className="btn tiny danger"
                        onClick={() => handleDelete(u.id)}
                        disabled={deletingId === u.id}
                      >
                        {deletingId === u.id ? "Deleting..." : "Delete"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* mobile cards */}
          <div className="card-grid">
            {users.map((u) => (
              <div className="user-card" key={`card-${u.id}`}>
                <div className="card-top">
                  <div className="card-id">#{u.id}</div>
                  <div className="card-name">{u.name}</div>
                </div>
                <div className="card-body">
                  <div><strong>Email:</strong> {u.email}</div>
                  <div><strong>Phone:</strong> {u.phone}</div>
                </div>
                <div className="card-footer">
                  <button className="btn tiny" onClick={() => handleEdit(u.id)}>Edit</button>
                  <button className="btn tiny danger" onClick={() => handleDelete(u.id)}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default UserList;
