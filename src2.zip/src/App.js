import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import UserList from "./components/UserList";
import CreateUser from "./pages/CreateUser";
import EditUser from "./pages/EditUser";

import "./App.css";

function App() {
  const [users, setUsers] = useState([]);

  // Warn user when reloading tab (browser shows native dialog)
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      e.preventDefault();
      e.returnValue = "All data will be lost if you reload this page!";
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, []);

  // Fetch Users Initially
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await fetch("https://jsonplaceholder.typicode.com/users");
        if (!res.ok) throw new Error("Failed to fetch");
        const data = await res.json();
        // Normalize ids to 1..N
        const normalized = data.map((u, i) => ({ ...u, id: i + 1 }));
        setUsers(normalized);
      } catch (err) {
        toast.error("Failed to fetch users");
      }
    };
    fetchUsers();
  }, []);

  return (
    <Router>
      <div className="app-dark">
        <ToastContainer position="top-right" />
        <header className="topbar">
          <div className="brand">
            <div className="brand-logo">CRUD</div>
            <div className="brand-text">
              <h1>User Management</h1>
              <span className="brand-sub">Controls every user with clarity.</span>
            </div>
          </div>

          <nav className="topnav">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/add" className="nav-cta">+ Add User</Link>
          </nav>
        </header>

        <main className="main-grid">
          <section className="content-card">
            <Routes>
              <Route path="/" element={<UserList users={users} setUsers={setUsers} />} />
              <Route path="/add" element={<CreateUser users={users} setUsers={setUsers} />} />
              <Route path="/edit/:id" element={<EditUser users={users} setUsers={setUsers} />} />
            </Routes>
          </section>

          <aside className="side-card">
            <div className="side-section">
              <h3>Quick actions</h3>
              <button
                className="btn small"
                onClick={() => toast.info("Try adding a user")}
              >
                Add sample
              </button>
            </div>

            <div className="side-section muted">
              <h4>Note</h4>
              <p>Data is temporary (JSONPlaceholder). Reloading the page resets data.</p>
            </div>
          </aside>
        </main>

        <footer className="footer">Made with ♥ — Demo app</footer>
      </div>
    </Router>
  );
}

export default App;
