import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function CreateUser({ users, setUsers }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!name.trim() || !email.trim() || !phone.trim()) {
      toast.error("Please fill all fields");
      return;
    }

    const newUser = {
      id: users.length + 1,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
    };

    setSubmitting(true);
    try {
      const res = await fetch("https://jsonplaceholder.typicode.com/users", {
        method: "POST",
        body: JSON.stringify(newUser),
        headers: { "Content-Type": "application/json; charset=UTF-8" },
      });

      if (!res.ok) throw new Error("Create failed");

      setUsers([...users, newUser]);
      toast.success("User added");
      setName("");
      setEmail("");
      setPhone("");
      navigate("/");
    } catch (err) {
      toast.error("Failed to create user. Try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="panel">
      <div className="panel-header">
        <h2>Add New User</h2>
        <p className="muted">Create a temporary user (demo only)</p>
      </div>

      <form className="form-grid" onSubmit={handleSubmit}>
        <label className="field">
          <span className="field-label">Name</span>
          <input
            className="input"
            type="text"
            placeholder="Full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </label>

        <label className="field">
          <span className="field-label">Email</span>
          <input
            className="input"
            type="email"
            placeholder="email@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>

        <label className="field">
          <span className="field-label">Phone</span>
          <input
            className="input"
            type="text"
            placeholder="+1 555 555 5555"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
          />
        </label>

        <div className="form-actions">
          <button className="btn" type="submit" disabled={submitting}>
            {submitting ? "Adding..." : "Add User"}
          </button>
          <button
            type="button"
            className="btn secondary"
            onClick={() => {
              setName("");
              setEmail("");
              setPhone("");
              toast.info("Cleared");
            }}
          >
            Clear
          </button>
        </div>
      </form>
    </div>
  );
}

export default CreateUser;
